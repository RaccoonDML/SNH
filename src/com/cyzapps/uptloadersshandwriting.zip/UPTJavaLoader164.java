package com.cyzapps.uptloadersshandwriting;
import com.cyzapps.mathrecog.UnitPrototypeMgr;
import com.cyzapps.mathrecog.UnitPrototypeMgr.UnitProtoType;

public class UPTJavaLoader164   {

	public static void load(UnitPrototypeMgr uptMgr) {
	}
}
